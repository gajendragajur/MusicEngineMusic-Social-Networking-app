import en from '../../locales/en.json';
import vi from '../../locales/vi.json';
export {en, vi}
