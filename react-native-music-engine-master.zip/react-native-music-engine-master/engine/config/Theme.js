module.exports = {
    dark: {
        name: "dark", //Do not change this
        defaultStatusBar: 'light-content',
        androidStatusBarColor: '#1a1b1c',
        androidStatusBarTranslucentColor: 'rgba(0,0,0,.5)',
        textSpotlightColor: '#e23137',
        headlineColor: '#e4e6eb',
        textPrimaryColor: '#e4e6eb',
        textSecondaryColor: '#b0b3b8',
        indicatorColor: '#fff',
        community: {
            shareBoxBackgroundColor: '#3a3b3c',
            sendButtonColor: '#1a77f2',
            textColor: '#e4e6eb',
            boxBorderColor: '#3e4043'
        },
        primaryButton: {
            backgroundColor: '#025EF7',
            textColor: '#fff',
        },
        topBar: {
            iconColor: '#e4e6eb'
        },
        bottomTabBar: {
            backgroundColor: '#2B2B2B',
            borderTopColor: '#303030'
        },
        miniPlayer: {
            backgroundColor: '#2B2B2B',
            iconColor: 'rgba(255, 255, 255, .8)',
            borderTopColor: '#303030',
            songColor: 'rgba(255, 255, 255, .8)',
            artistColor: 'rgba(255, 255, 255, .4)',
            timeProcess: {
                processColor: 'rgba(255,255,255,.1)',
                processedColor: '#e23137'
            }
        },
        player: {
            queueBackgroundColor: '#111',
            queueHeaderBackgroundColor: '#1a1b1c',
            queueHeaderTextColor: '#fff',
            queueNumberTextColor: '#fff',
            songTitleColor: '#fff',
            songArtistColor: '#ffffff99',
            queueBorderTopColor: 'rgba(255,255,255,.2)',
            buttonColor: 'rgba(255, 255, 255, .8)',
            timeTextColor: '#fff',
            timeProcess: {
                processColor: 'rgba(255,255,255,.1)',
                processedColor: '#e23137'
            },
            actionsActiveIconColor: '#e23137',
            actionsInactiveIconColor: '#fff'

        },
        profile: {
            actionsIconColor: '#fff',
            actionsActiveIconColor: '#e23137',
            notifBadgeColor: '#b0b3b8',
            notifBadgeTextColor: '#fefefe',
            userNameTextColor: '#fefefe',
            friendNameTextColor: '#666666'
        },
        searchBar: {
            backgroundColor: '#424242',
            placeholderTextColor: '#878789',
            cancelTextColor: '#e4e4e6',
            inputTextColor: '#e4e4e6',
        },
        songInfoModal: {
            backgroundColor: '#232327',
            footerBackgroundColor: '#232327', //'#e4e4e4'
            footerTopBorderColor: '#323136', //#fff
            buttonColor: '#38383c',//#f5f5f5
            buttonTextColor: '#fff'
        },
        activity: {
            borderColor: '#323136',
            authorTextColor: '#b0b3b8',
            actionTextColor: '#b0b3b8',
            objectTextColor: '#b0b3b8',
            timeTextColor: '#b0b3b8'
        },
        textInput: {
            borderColor: '#f0f2f5',
            backgroundColor: '#f0f2f5',
            placeholderTextColor: '#898888',
            textColor: '#65676b'
        },
        switch: {
            falseColor: '#656665',
            trueColor: '#e23137',
            thumbColor: '#fff'
        },
        parallax: {
            iconColor: '#D9D5DA',
            iconActiveColor: '#e23137',
            colors: ['rgba(27, 27, 27,.75)', 'rgba(27, 27, 27,.85)', 'rgba(27, 27, 27, 1)'],
            primaryButtonColor: '#025EF7',
            secondaryButtonColor: '#3C3C3C',
        },
        modal: {
            closeButtonColor: '#fff',
            titleColor: '#fff',
            createPlaylistButtonColor: '#fff'
        },
        staticPage: {
            fontColor: '#b2b2b2'
        },
        feedItem: {
            postFeedBackgroundColor: '#1ca1f8',
            sharedMusicBackgroundColor: '#34c657',
            commentMusicBackgroundColor: '#34c657',
            commentMentionedBackgroundColor: '#34c657',
            replyCommentBackgroundColor: '#34c657',
            addSongBackgroundColor: '#34c657',
            addToPlaylistBackgroundColor: '#1ca1f8',
            acceptedCollaborationBackgroundColor: '#1ca1f8',
            inviteCollaborationBackgroundColor: '#1ca1f8',
            followUserBackgroundColor: '#df2291',
            followArtistBackgroundColor: '#7e46eb',
            followPlaylistBackgroundColor: '#1ca1f8',
            playSongBackgroundColor: '#27bca9',
            collectSongBackgroundColor: '#eda209',
            favoriteSongBackgroundColor: '#e23037',

        },
        comment: {
            backgroundColor: '#3a3b3c',
            reactionsBackgroundColor: '#3e4043'
        },
        primaryBackgroundColor: "#1b1b1b",
        secondaryBackgroundColor: "#303030",
        barBackgroundColor: '#1a1b1c',
        barIconColor: '#969796',
        buttonColor: '#e23137',
        barIconColorActive: '#e23137',
        barTextColor: '#878789',

        iconColor: 'rgba(255, 255, 255, .8)',
        navBackgroundColor: '#1b1b1b',
        navBorderColor: '#303030',


        stickyHeaderBackgroundColor: '#101418',

        noDataTextColor: 'rgba(255, 255, 255, .8)',

        searchBarBackgroundColor: '#000000',

        tabBackgroundColor: '#1a1b1c',
        tabBorderBottomColor: 'rgba(0, 0, 0, 0.3)',

        moreTextColor: '#bbbbbb',
        moreIconColor: '#959595',
        profileIconColor: 'rgba(255, 255, 255, .8)',
        buttonTextColor: '#fff',
        contextMenuBackgroundColor: '#333333',
        contextMenuIconColor: '#959595',
        genreTextColor: '#fff',
        navIconColor: '#fff',
        showHeaderColor: '#fefefe',
        showSubColor: '#f3f2f2',
        showStickyHeaderColor: '#fff',
        showStickyDescrColor: '#e4e4e6',
        showTypeColor: '#f3f2f2',

        queueSongIndex: '#868688',
        queueSongHeaderColor: '#fefeff',
        queueSongSubColor: '#868688',
        tabUnderlineColor: '#e23137',

        profileHeaderColor: '#222632',

        loginModalBackgroundColor: '#222632',
        slideShowTitleColor: '#fff',
        slideShowSubColor: '#eee',

        playlistMoreButtonColor: '#868688',

        inviteButtonBackgroundColor: '#e23137',
        inviteButtonTextColor: '#ffffff',

        activityIndicator: {
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            height: 50,
            color: '#e23137'
        },
        settings: {
            headerBoxBackgroundColor: '#e23137',
            headerTextColor: '#fff',
            headerIconColor: '#fff'
        },
        radio: {
            categoryTextColor: '#fff',
            categoryIconColor: '#fff'
        },
        commentBox: {
            backgroundColor: '#2B2B2B',
            commentFieldBackgroundColor: '#3a3b3c',
            placeholderTextColor: '#b0b3b8',
            textColor: '#3a3b3c'

        }
    },
    //Light theme
    light: {
        name: "light",
        androidStatusBarColor: '#fff',
        androidStatusBarTranslucentColor: 'rgba(0,0,0,.2)',
        defaultStatusBar: 'dark-content',
        textSpotlightColor: '#e23137',
        textPrimaryColor: '#000000',
        textSecondaryColor: '#656567',
        indicatorColor: '#000',
        community: {
            shareBoxBackgroundColor: '#f0f2f5',
            sendButtonColor: '#1a77f2',
            textColor: '#050504',
            boxBorderColor: '#ced0d4'
        },
        primaryButton: {
            backgroundColor: '#025EF7',
            textColor: '#fff',
        },
        topBar: {
            iconColor: '#000'
        },
        bottomTabBar: {
            backgroundColor: '#ffffff',
            borderTopColor: '#b8b8b8'
        },
        miniPlayer: {
            backgroundColor: '#f8f8fa',
            iconColor: '#000000',
            borderTopColor: '#eaeae9',
            songColor: '#000001',
            artistColor: '#656567',
            timeProcess: {
                processColor: 'transparent',
                processedColor: '#e23137'
            }
        },
        player: {
            queueBackgroundColor: '#fff',
            queueHeaderBackgroundColor: '#efefef',
            queueHeaderTextColor: 'rgba(0,0,0,.7)',
            songTitleColor: '#000',
            songArtistColor: 'rgba(0,0,0,.6)',
            queueBorderTopColor: 'rgba(0,0,0,.2)',
            buttonColor: '#111111',
            timeTextColor: 'rgba(0,0,0,.9)',
            timeProcess: {
                processColor: 'rgba(17,17,17,.1)',
                processedColor: '#e23137'
            },
            actionsActiveIconColor: '#e23137',
            actionsInactiveIconColor: '#111'
        },
        profile: {
            actionsIconColor: '#000',
            actionsActiveIconColor: '#e23137',
            notifBadgeColor: '#656567',
            notifBadgeTextColor: '#fff',
            userNameTextColor: '#000',
            friendNameTextColor: '#666666'
        },
        searchBar: {
            backgroundColor: '#e4e4e6',
            placeholderTextColor: '#878789',
            cancelTextColor: '#222632',
            inputTextColor: '#222632',
        },
        songInfoModal: {
            backgroundColor: '#fff',
            footerBackgroundColor: '#e4e4e4',
            footerTopBorderColor: '#fff',
            buttonColor: '#fff',
            buttonTextColor: '#000'
        },
        activity: {
            borderColor: '#eee',
            authorTextColor: '#000000',
            actionTextColor: '#000000',
            objectTextColor: '#656567',
            timeTextColor: '#9a9999'
        },
        textInput: {
            borderColor: '#7c7c7c',
            backgroundColor: '#f8f8f8',
            placeholderTextColor: '#545454',
            textColor: '#000000'
        },
        switch: {
            falseColor: '#cdcdcc',
            trueColor: '#e23137',
            thumbColor: '#fff'
        },

        parallax: {
            iconColor: '#65676b',
            iconActiveColor: '#e23137',
            colors: ['rgba(255,255,255,.55)', 'rgba(255,255,255,.80)', 'rgba(255,255,255,1)'],
            primaryButtonColor: '#025EF7',
            secondaryButtonColor: '#e4e6ea',
        },

        modal: {
            closeButtonColor: '#000000',
            titleColor: '#000000',
            createPlaylistButtonColor: '#000000'
        },
        staticPage: {
            fontColor: '#656567'
        },
        feedItem: {
            postFeedBackgroundColor: '#1ca1f8',
            sharedMusicBackgroundColor: '#34c657',
            commentMusicBackgroundColor: '#34c657',
            commentMentionedBackgroundColor: '#34c657',
            replyCommentBackgroundColor: '#34c657',
            addSongBackgroundColor: '#34c657',
            addToPlaylistBackgroundColor: '#1ca1f8',
            acceptedCollaborationBackgroundColor: '#1ca1f8',
            inviteCollaborationBackgroundColor: '#1ca1f8',
            followUserBackgroundColor: '#df2291',
            followArtistBackgroundColor: '#7e46eb',
            followPlaylistBackgroundColor: '#1ca1f8',
            playSongBackgroundColor: '#27bca9',
            collectSongBackgroundColor: '#eda209',
        },
        comment: {
            backgroundColor: '#f0f2f5',
            reactionsBackgroundColor: '#ffffff'
        },
        //common style
        primaryBackgroundColor: "#fff",
        secondaryBackgroundColor: "#dcdcdc",
        barBackgroundColor: '#fff',
        barIconColor: '#888887',
        barIconColorActive: '#e23137',
        barTextColor: '#000001',
        buttonColor: '#e23137',
        buttonTextColor: '#fff',

        headlineColor: '#000001',
        contextMenuBackgroundColor: '#ffffff',
        contextMenuIconColor: '#878789',

        noDataTextColor: '#222632',


        genreTextColor: '#ffff',
        navBackgroundColor: '#fff',
        navBorderColor: '#d8d8d8',

        navIconColor: '#000000',

        stickyHeaderBackgroundColor: '#ffffff',

        showHeaderColor: '#fefefe',
        showSubColor: '#f3f2f2',
        showStickyHeaderColor: '#fff',
        showStickyDescrColor: '#e4e4e6',
        showTypeColor: '#f3f2f2',

        queueSongIndex: '#868688',
        queueSongHeaderColor: '#fefeff',
        queueSongSubColor: '#868688',
        tabBackgroundColor: '#ffffff',
        tabBorderBottomColor: '#d8d8d8',
        tabUnderlineColor: '#e23137',

        moreTextColor: '#696c6e',
        moreIconColor: '#959595',

        profileIconColor: '#878789',
        profileHeaderColor: '#222632',

        loginModalBackgroundColor: '#222632',
        slideShowTitleColor: '#fff',
        slideShowSubColor: '#eee',
        playlistMoreButtonColor: '#222632',

        inviteButtonBackgroundColor: '#e23137',
        inviteButtonTextColor: '#ffffff',
        activityIndicator: {
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            height: 50,
            color: '#e23137'
        },
        settings: {
            headerBoxBackgroundColor: '#e23137',
            headerTextColor: '#fff',
            headerIconColor: '#fff'
        },

        radio: {
            categoryTextColor: '#e23137',
            categoryIconColor: '#111'
        },

        commentBox: {
            backgroundColor: '#ffffff',
            commentFieldBackgroundColor: '#f0f2f5',
            placeholderTextColor: '#65676b',
            textColor: '#050505'

        }
    }
}
