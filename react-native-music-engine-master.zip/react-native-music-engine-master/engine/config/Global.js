/**
 * Created by ninacoder
 * @https://codecanyon.net/user/codenamenina
 */

const THEME = require('./Theme');

module.exports = {
    //default language at first
    languages: ['en', 'vi'],
    APP_NAME: 'Music Engine',
    API_URL: 'https://musicengine.top/api',
    DEEP_LINK_SCHEME: 'musicengine',
    OWNER_EMAIL: 'ninacoder2510@gmail.com',
    VERSION: '1.0.0',
    ENABLE_STORE: true,
    ADMOB_BANNER_UNIT_ID: false,
    SIGN_IN_WITH_FACEBOOK: true,
    SIGN_IN_WITH_TWITTER: true,
    SIGN_IN_WITH_APPLE: true,
    SIGN_IN_WITH_GOOGLE: true,
    DEFAULT_DARK_MODE: true,
    ENABLE_PODCAST: true,
    ENABLE_RADIO: true,
    SHOW_TAB_MENU_NAME: true,
    themes: THEME // DO NOT  CHANGE THIS
};
